library(testthat)
library(CBPS)

test_check("CBPS")
